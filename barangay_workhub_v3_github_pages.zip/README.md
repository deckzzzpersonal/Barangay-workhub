# Barangay WorkHub v3 — GitHub Pages + Supabase

This package is prepared to deploy the Barangay WorkHub front end through **GitHub Pages** while using **Supabase** for authentication and the cloud database.

## Important architecture

- GitHub Pages = website hosting
- Supabase = login + cloud database + Row Level Security
- `public/index.html` = application
- `supabase/schema.sql` = database/security setup

## 1. Create the Supabase backend

1. Create a Supabase project.
2. Open **SQL Editor**.
3. Run the complete `supabase/schema.sql`.
4. In Supabase Authentication, enable Email/Password.
5. Create your first account.

After signing in for the first time, use **Setup Barangay Workspace**. It creates the Barangay Villaflor workspace and makes your first account an admin.

## 2. Configure the site

Create a file:

`public/config.js`

based on:

`public/config.example.js`

Put in:

```js
window.SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
window.SUPABASE_ANON_KEY = "YOUR-PUBLISHABLE-KEY";
```

Use the Supabase **publishable/anon** browser key only. Never use a `service_role`/secret key in this website.

### GitHub Pages note

Because `public/config.js` contains the public browser key, you can commit it if you understand that the Supabase publishable/anon key is intended to be exposed to browser clients. The real security boundary is your Supabase RLS policies. Do NOT put passwords, service-role keys, or other secrets in it.

For a cleaner repository, you may instead add a build step that creates `public/config.js` from GitHub Actions secrets/variables. This is optional; it is not required for the anon/publishable key.

## 3. Create the GitHub repository

Create a new repository, for example:

`barangay-workhub`

Keep the repository public if using GitHub Free and GitHub Pages in the simplest configuration.

Then upload/push the contents of this package so the repository contains:

```text
.github/
  workflows/
    deploy.yml
public/
  index.html
  config.js
  config.example.js
supabase/
  schema.sql
.nojekyll
.gitignore
README.md
```

## 4. Turn on GitHub Pages

In the GitHub repository:

**Settings → Pages**

Under **Build and deployment**, select:

**Source: GitHub Actions**

Then push to the `main` branch.

The included workflow automatically deploys the `public` folder.

Your site will normally be available at:

`https://YOUR-GITHUB-USERNAME.github.io/barangay-workhub/`

GitHub may take a short time to publish the first deployment.

## 5. Supabase Auth URL settings

In Supabase:

**Authentication → URL Configuration**

Set the **Site URL** to your GitHub Pages address, for example:

`https://YOUR-GITHUB-USERNAME.github.io/barangay-workhub/`

Add the same URL under **Redirect URLs** if needed by your authentication configuration.

## 6. Test from your phone

Open the GitHub Pages URL on your Android phone.

1. Create/sign in to your account.
2. Setup the Barangay Villaflor workspace.
3. Add an activity.
4. Open the site on another device.
5. Sign in with the same account.
6. The same record should appear because it is stored in Supabase.

## Current V3 modules

- Dashboard
- Daily Activities
- Tasks & Follow-ups
- Resolutions & Ordinances
- Projects & Infrastructure
- Sessions & Meetings
- Notes & Ideas
- Accomplishment Report draft
- Authentication
- Cloud database
- Workspace isolation
- Row Level Security

## Recommended next upgrade

For official barangay use, the next release should add:

- role-based permissions for Punong Barangay / Kagawads / Secretary / staff
- audit trail
- document/PDF uploads
- resolution and ordinance document generator
- automatic numbering
- session agenda and minutes
- project progress photos
- accomplishment report templates
- database backup/export
- custom domain
- stronger account recovery and administrative controls

Before storing sensitive official documents, review your LGU's records-management, privacy, and security requirements.
