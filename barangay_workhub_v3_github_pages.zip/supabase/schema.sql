
-- BARANGAY WORKHUB V3 DATABASE
-- Run this entire file in Supabase SQL Editor.
-- Security model: authenticated users in the same barangay workspace can collaborate.
-- RLS is enabled on every application table.

create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  municipality text,
  province text,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  workspace_id uuid references public.workspaces(id) on delete set null,
  full_name text,
  role text not null default 'staff' check (role in ('admin','captain','kagawad','staff','viewer')),
  created_at timestamptz not null default now()
);

create table if not exists public.activities (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete restrict,
  activity_date date not null default current_date,
  activity text not null,
  category text not null default 'Administration',
  action text,
  follow_up text,
  people text,
  status text not null default 'Completed',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.tasks (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete restrict,
  task text not null,
  area text,
  due_date date,
  priority text not null default 'Normal',
  status text not null default 'Pending',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.legislative (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete restrict,
  type text not null default 'Resolution',
  number text,
  title text not null,
  document_date date default current_date,
  status text not null default 'Draft',
  rationale text,
  legal_basis text,
  draft_text text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.projects (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete restrict,
  title text not null,
  sector text default 'Infrastructure',
  location text default 'Barangay Villaflor',
  funding_source text,
  amount numeric,
  status text not null default 'Proposed',
  progress text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.meetings (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete restrict,
  meeting_date date not null default current_date,
  title text not null,
  venue text default 'Barangay Hall',
  organizer text,
  status text not null default 'Planned',
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.notes (
  id uuid primary key default gen_random_uuid(),
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete restrict,
  title text not null,
  category text,
  body text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists activities_workspace_date on public.activities(workspace_id, activity_date desc);
create index if not exists tasks_workspace_due on public.tasks(workspace_id, due_date);
create index if not exists legislative_workspace_date on public.legislative(workspace_id, document_date desc);
create index if not exists projects_workspace on public.projects(workspace_id);
create index if not exists meetings_workspace_date on public.meetings(workspace_id, meeting_date);
create index if not exists notes_workspace on public.notes(workspace_id);

-- Workspace membership helper
create or replace function public.my_workspace_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select workspace_id from public.profiles where id = auth.uid()
$$;

-- Enable RLS
alter table public.workspaces enable row level security;
alter table public.profiles enable row level security;
alter table public.activities enable row level security;
alter table public.tasks enable row level security;
alter table public.legislative enable row level security;
alter table public.projects enable row level security;
alter table public.meetings enable row level security;
alter table public.notes enable row level security;

-- Policies
drop policy if exists "workspace members can read workspace" on public.workspaces;
create policy "workspace members can read workspace" on public.workspaces
for select to authenticated using (id = (select public.my_workspace_id()));

drop policy if exists "users can read own profile" on public.profiles;
create policy "users can read own profile" on public.profiles
for select to authenticated using (id = (select auth.uid()));

drop policy if exists "workspace members read activities" on public.activities;
create policy "workspace members read activities" on public.activities
for select to authenticated using (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members insert activities" on public.activities;
create policy "workspace members insert activities" on public.activities
for insert to authenticated with check (workspace_id = (select public.my_workspace_id()) and user_id = (select auth.uid()));
drop policy if exists "workspace members update activities" on public.activities;
create policy "workspace members update activities" on public.activities
for update to authenticated using (workspace_id = (select public.my_workspace_id())) with check (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members delete activities" on public.activities;
create policy "workspace members delete activities" on public.activities
for delete to authenticated using (workspace_id = (select public.my_workspace_id()));

drop policy if exists "workspace members read tasks" on public.tasks;
create policy "workspace members read tasks" on public.tasks for select to authenticated using (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members insert tasks" on public.tasks;
create policy "workspace members insert tasks" on public.tasks for insert to authenticated with check (workspace_id = (select public.my_workspace_id()) and user_id = (select auth.uid()));
drop policy if exists "workspace members update tasks" on public.tasks;
create policy "workspace members update tasks" on public.tasks for update to authenticated using (workspace_id = (select public.my_workspace_id())) with check (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members delete tasks" on public.tasks;
create policy "workspace members delete tasks" on public.tasks for delete to authenticated using (workspace_id = (select public.my_workspace_id()));

drop policy if exists "workspace members read legislative" on public.legislative;
create policy "workspace members read legislative" on public.legislative for select to authenticated using (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members insert legislative" on public.legislative;
create policy "workspace members insert legislative" on public.legislative for insert to authenticated with check (workspace_id = (select public.my_workspace_id()) and user_id = (select auth.uid()));
drop policy if exists "workspace members update legislative" on public.legislative;
create policy "workspace members update legislative" on public.legislative for update to authenticated using (workspace_id = (select public.my_workspace_id())) with check (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members delete legislative" on public.legislative;
create policy "workspace members delete legislative" on public.legislative for delete to authenticated using (workspace_id = (select public.my_workspace_id()));

drop policy if exists "workspace members read projects" on public.projects;
create policy "workspace members read projects" on public.projects for select to authenticated using (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members insert projects" on public.projects;
create policy "workspace members insert projects" on public.projects for insert to authenticated with check (workspace_id = (select public.my_workspace_id()) and user_id = (select auth.uid()));
drop policy if exists "workspace members update projects" on public.projects;
create policy "workspace members update projects" on public.projects for update to authenticated using (workspace_id = (select public.my_workspace_id())) with check (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members delete projects" on public.projects;
create policy "workspace members delete projects" on public.projects for delete to authenticated using (workspace_id = (select public.my_workspace_id()));

drop policy if exists "workspace members read meetings" on public.meetings;
create policy "workspace members read meetings" on public.meetings for select to authenticated using (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members insert meetings" on public.meetings;
create policy "workspace members insert meetings" on public.meetings for insert to authenticated with check (workspace_id = (select public.my_workspace_id()) and user_id = (select auth.uid()));
drop policy if exists "workspace members update meetings" on public.meetings;
create policy "workspace members update meetings" on public.meetings for update to authenticated using (workspace_id = (select public.my_workspace_id())) with check (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members delete meetings" on public.meetings;
create policy "workspace members delete meetings" on public.meetings for delete to authenticated using (workspace_id = (select public.my_workspace_id()));

drop policy if exists "workspace members read notes" on public.notes;
create policy "workspace members read notes" on public.notes for select to authenticated using (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members insert notes" on public.notes;
create policy "workspace members insert notes" on public.notes for insert to authenticated with check (workspace_id = (select public.my_workspace_id()) and user_id = (select auth.uid()));
drop policy if exists "workspace members update notes" on public.notes;
create policy "workspace members update notes" on public.notes for update to authenticated using (workspace_id = (select public.my_workspace_id())) with check (workspace_id = (select public.my_workspace_id()));
drop policy if exists "workspace members delete notes" on public.notes;
create policy "workspace members delete notes" on public.notes for delete to authenticated using (workspace_id = (select public.my_workspace_id()));

-- Signup trigger: profile only. Workspace is assigned by the first-admin setup function below.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles(id, full_name) values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''));
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- One-time bootstrap: after creating the first account, run:
-- select public.bootstrap_workspace('YOUR_USER_UUID');
create or replace function public.bootstrap_workspace(p_user uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare w uuid;
begin
  if auth.uid() is null or auth.uid() <> p_user then
    raise exception 'Only the signed-in user can bootstrap their own workspace';
  end if;
  if exists(select 1 from profiles where id=p_user and workspace_id is not null) then
    return (select workspace_id from profiles where id=p_user);
  end if;
  insert into workspaces(name, municipality, province)
  values ('Barangay Villaflor','Tobias Fornier','Antique') returning id into w;
  update profiles set workspace_id=w, role='admin' where id=p_user;
  return w;
end;
$$;

grant execute on function public.bootstrap_workspace(uuid) to authenticated;
