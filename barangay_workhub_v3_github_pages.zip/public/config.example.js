// Copy this file to public/config.js.
// IMPORTANT: use only the Supabase publishable/anon browser key.
// NEVER put a service_role/secret key in this file.
//
// For GitHub Pages, config.js is intentionally gitignored.
// Upload it separately to your deployed site, or use the safer
// build-time approach described in README.md.

window.SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
window.SUPABASE_ANON_KEY = "YOUR-PUBLISHABLE-KEY";
