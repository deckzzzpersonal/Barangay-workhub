# Quick GitHub Setup

1. Create a GitHub repository named `barangay-workhub`.
2. Upload all files in this folder.
3. Create `public/config.js` from `public/config.example.js`.
4. Put your Supabase URL and publishable/anon key in `config.js`.
5. Commit/push to `main`.
6. GitHub: Settings → Pages → Source → GitHub Actions.
7. Wait for the `Deploy Barangay WorkHub to GitHub Pages` workflow to finish.
8. Open the published Pages URL.
9. In Supabase Authentication → URL Configuration, set the Pages URL as the Site URL/Redirect URL.

Never place a Supabase service_role/secret key in the repository or browser code.
